1. Default Location. Put the .SKA file(s) in %localappdata%\THUG Pro\Save
2. Custom Location. Put the .SKA file(s) in THUG PRO INSTALL\Save
